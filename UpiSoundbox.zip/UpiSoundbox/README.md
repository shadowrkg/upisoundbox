# UPI Soundbox – setup

## Project skeleton
Create an Empty Views Activity project (package `com.example.upisoundbox`, minSdk 26), then drop in
`app/build.gradle.kts`, `AndroidManifest.xml`, the Kotlin files and the two layouts.
Root `build.gradle.kts` needs the usual plugins:
    id("com.android.application") version "8.7.3" apply false
    id("org.jetbrains.kotlin.android") version "2.0.21" apply false

## Dependencies
See `app/build.gradle.kts` (core-ktx, appcompat, material, recyclerview, lifecycle-runtime-ktx).

## First run
1. Install, open the app, allow the notification permission (Android 13+).
2. Tap **Grant Notification Access**, enable "UPI Soundbox".
3. Tap **Test voice announcement**. If it's English, install Hindi voice data:
   Settings > System > Languages > Text-to-speech output > Google engine > Install voice data > Hindi.
4. Tap **Disable battery optimization** and choose All apps > UPI Soundbox > Don't optimize.

## Surviving aggressive battery management
- Battery: Settings > Apps > UPI Soundbox > Battery > **Unrestricted**.
- Pin the app in Recents (lock icon / "Keep open") so it isn't swept.
- OEM extras (Xiaomi/Redmi, Oppo/Realme, Vivo, OnePlus, Samsung, Huawei):
  - Xiaomi/Redmi: Security > Permissions > Autostart > enable; Battery saver > No restrictions.
  - Oppo/Realme/OnePlus: Allow auto-launch + Allow background activity.
  - Vivo: iManager > App manager > Autostart; High background power consumption > allow.
  - Samsung: Battery > Background usage limits > Never auto sleeping apps > add.
- Keep the phone's media volume up; announcements use the media stream.
- If the listener ever stops: toggle Notification Access off/on once.
- Also keep GPay/PhonePe/Paytm/BHIM notifications enabled and not silenced.

## Manifest notes
- `BIND_NOTIFICATION_LISTENER_SERVICE` is declared on the `<service>` (that's where Android requires it).
- `FOREGROUND_SERVICE_SPECIAL_USE` is one extra permission Android 14+ forces for typed foreground services.
