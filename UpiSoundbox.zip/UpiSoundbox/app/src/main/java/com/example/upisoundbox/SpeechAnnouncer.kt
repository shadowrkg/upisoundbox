package com.example.upisoundbox

import android.content.Context
import android.media.AudioAttributes
import android.speech.tts.TextToSpeech
import java.util.Locale

/** Singleton TTS wrapper. Uses Hindi if the device has a hi-IN voice, otherwise English. */
object SpeechAnnouncer {
    private var tts: TextToSpeech? = null
    private var ready = false
    private var hindi = false
    private val queue = ArrayDeque<Pair<String, String>>() // appName to amount

    @Synchronized
    fun init(context: Context) {
        if (tts != null) return
        tts = TextToSpeech(context.applicationContext) { status ->
            synchronized(this) {
                if (status != TextToSpeech.SUCCESS) { tts = null; return@synchronized }
                val engine = tts!!
                engine.setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
                )
                val hi = engine.setLanguage(Locale.forLanguageTag("hi-IN"))
                hindi = hi >= TextToSpeech.LANG_AVAILABLE
                if (!hindi) engine.setLanguage(Locale.ENGLISH)
                ready = true
                while (queue.isNotEmpty()) queue.removeFirst().let { speakNow(it.first, it.second) }
            }
        }
    }

    @Synchronized
    fun announce(context: Context, appName: String, amount: String) {
        init(context)
        if (ready) speakNow(appName, amount) else queue.addLast(appName to amount)
    }

    private fun speakNow(appName: String, amount: String) {
        val text = if (hindi) "$appName पर $amount रुपये प्राप्त हुए"
        else "Received $amount rupees on $appName"
        tts?.speak(text, TextToSpeech.QUEUE_ADD, null, "pay-${System.nanoTime()}")
    }
}
