package com.example.upisoundbox

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import org.json.JSONArray
import org.json.JSONObject

/** Tiny persistent history store (last 200 payments) backed by SharedPreferences. */
object PaymentRepository {
    private const val PREFS = "payments"
    private const val KEY = "history"
    private const val MAX = 200

    private val _history = MutableStateFlow<List<Payment>>(emptyList())
    val history: StateFlow<List<Payment>> = _history
    private var loaded = false

    @Synchronized
    fun load(context: Context) {
        if (loaded) return
        loaded = true
        val json = context.applicationContext
            .getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY, null) ?: return
        runCatching {
            val arr = JSONArray(json)
            _history.value = (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                Payment(o.getString("app"), o.getString("amt"), o.getString("from"), o.getLong("ts"))
            }
        }
    }

    @Synchronized
    fun add(context: Context, payment: Payment) {
        load(context)
        val updated = (listOf(payment) + _history.value).take(MAX)
        _history.value = updated
        val arr = JSONArray()
        updated.forEach {
            arr.put(JSONObject().put("app", it.appName).put("amt", it.amount)
                .put("from", it.sender).put("ts", it.timestamp))
        }
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY, arr.toString()).apply()
    }
}
