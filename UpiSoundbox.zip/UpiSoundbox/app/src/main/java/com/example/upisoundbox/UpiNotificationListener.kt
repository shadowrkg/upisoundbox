package com.example.upisoundbox

import android.app.Notification
import android.content.ComponentName
import android.content.Context
import android.os.PowerManager
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class UpiNotificationListener : NotificationListenerService() {

    companion object {
        /** Package name -> display name used in the announcement. */
        val UPI_APPS = mapOf(
            "com.google.android.apps.nbu.paisa.user" to "Google Pay",
            "com.phonepe.app" to "PhonePe",
            "com.phonepe.merchant" to "PhonePe Business",
            "net.one97.paytm" to "Paytm",
            "in.org.npci.upiapp" to "BHIM"
        )
        private const val DEDUPE_WINDOW_MS = 10_000L
        private val recent = LinkedHashMap<String, Long>()
    }

    override fun onCreate() {
        super.onCreate()
        PaymentRepository.load(this)
        SpeechAnnouncer.init(this)
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val appName = UPI_APPS[sbn.packageName] ?: return
        val n = sbn.notification ?: return
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return

        val extras = n.extras
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val body = (extras.getCharSequence(Notification.EXTRA_BIG_TEXT)
            ?: extras.getCharSequence(Notification.EXTRA_TEXT))?.toString().orEmpty()

        val parsed = PaymentParser.parse(title, body) ?: return
        if (isDuplicate("${sbn.packageName}|$title|$body")) return

        val payment = Payment(appName, parsed.amount, parsed.sender, System.currentTimeMillis())
        PaymentRepository.add(this, payment)

        // Keep the CPU awake briefly so the announcement isn't cut off in Doze.
        val wl = (getSystemService(Context.POWER_SERVICE) as PowerManager)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "upisoundbox:announce")
        wl.acquire(10_000L)
        SpeechAnnouncer.announce(this, appName, parsed.amount)
    }

    @Synchronized
    private fun isDuplicate(key: String): Boolean {
        val now = System.currentTimeMillis()
        recent.entries.removeAll { now - it.value > DEDUPE_WINDOW_MS }
        if (recent.containsKey(key)) return true
        recent[key] = now
        return false
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        // Ask the system to rebind us if it dropped the connection.
        requestRebind(ComponentName(this, UpiNotificationListener::class.java))
    }
}
