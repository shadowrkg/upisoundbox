package com.example.upisoundbox

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import java.text.DateFormat
import java.util.Date

class PaymentAdapter : ListAdapter<Payment, PaymentAdapter.VH>(Diff) {

    object Diff : DiffUtil.ItemCallback<Payment>() {
        override fun areItemsTheSame(a: Payment, b: Payment) = a.timestamp == b.timestamp && a.amount == b.amount
        override fun areContentsTheSame(a: Payment, b: Payment) = a == b
    }

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val app: TextView = v.findViewById(R.id.tvApp)
        val detail: TextView = v.findViewById(R.id.tvDetail)
        val amount: TextView = v.findViewById(R.id.tvAmount)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_payment, parent, false))

    override fun onBindViewHolder(h: VH, position: Int) {
        val p = getItem(position)
        h.app.text = p.appName
        h.detail.text = "${p.sender} • " +
            DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(Date(p.timestamp))
        h.amount.text = "₹${p.amount}"
    }
}
