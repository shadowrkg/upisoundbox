package com.example.upisoundbox

data class Payment(
    val appName: String,
    val amount: String,
    val sender: String,
    val timestamp: Long
)
