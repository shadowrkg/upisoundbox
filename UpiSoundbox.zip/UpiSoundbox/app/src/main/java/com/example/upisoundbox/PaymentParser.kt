package com.example.upisoundbox

import java.math.BigDecimal

data class ParsedPayment(val amount: String, val sender: String)

object PaymentParser {

    private const val AMT = """(?:rs\.?|₹|inr)\s*([\d,]+(?:\.\d{1,2})?)"""

    // Anything that is NOT a real, completed incoming payment.
    private val REJECT = Regex(
        """cashback|cash back|reward|offer|coupon|scratch|voucher|reminder|remind|""" +
        """requested|request(?:s|ed)? (?:money|payment)|collect request|pending|failed|declined|""" +
        """debited|you paid|you sent|paid to|sent to|payment to|""" +
        """due\b|expire|overdue|up ?to|flat\b|% ?off|\bwin\b|\bearn\b|bonus|pay now|tap to|""" +
        """bill|recharge|reversed|will be credited|to be credited""",
        RegexOption.IGNORE_CASE
    )

    // Credit phrases; group(1) is always the amount.
    private val CREDIT = listOf(
        Regex("""(?:received|credited|got)\s*(?:by|of|:)?\s*$AMT""", RegexOption.IGNORE_CASE), // received ₹100 / credited by ₹100
        Regex("""(?:paid|sent)\s+you\s*$AMT""", RegexOption.IGNORE_CASE),                       // X paid you ₹100
        Regex("""$AMT\s*(?:has been\s+|was\s+|is\s+)?(?:received|credited)""", RegexOption.IGNORE_CASE) // ₹100 received
    )

    private val SENDER = listOf(
        Regex("""^(.+?)\s+(?:paid|sent)\s+you""", RegexOption.IGNORE_CASE),
        Regex("""\bfrom\s+(.+?)(?=\s+(?:on|via|to|using|with|ref|upi|at)\b|\s*[.,;(\-|]|$)""", RegexOption.IGNORE_CASE)
    )

    fun parse(title: String, body: String): ParsedPayment? {
        val text = "$title $body".replace('\u00A0', ' ').replace(Regex("\\s+"), " ").trim()
        if (text.isEmpty() || REJECT.containsMatchIn(text)) return null

        val amountRaw = CREDIT.firstNotNullOfOrNull { it.find(text)?.groupValues?.get(1) } ?: return null
        val amount = runCatching { BigDecimal(amountRaw.replace(",", "")).stripTrailingZeros() }
            .getOrNull()?.takeIf { it.signum() > 0 }?.toPlainString() ?: return null

        // Prefer matching sender in the title+body combined, falling back to body / title alone.
        val sender = listOf(text, body, title).firstNotNullOfOrNull { s ->
            SENDER.firstNotNullOfOrNull { it.find(s)?.groupValues?.get(1)?.trim() }
        }?.takeIf { it.length in 2..60 && !it.contains('₹') && !it.contains("rs", true).and(it.any(Char::isDigit)) }
            ?: "Unknown"

        return ParsedPayment(amount, sender)
    }
}
